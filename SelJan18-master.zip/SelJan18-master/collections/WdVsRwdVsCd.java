package collections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class WdVsRwdVsCd {

	public static void main(String[] args) {
		
		// Interface
		WebDriver driver = new FirefoxDriver();
		
		// Class
		RemoteWebDriver driver1 = new FirefoxDriver();
		
		// Sub Class
		FirefoxDriver driver2 = new FirefoxDriver();
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
