package learnJava;

public class Auto extends Vehicle{
	
	public void turnMeter(){
		
	}

}
