package learnJava;

public class RideBicycle {

	public static void main(String[] args) {
		
		Bicycle cycle = new Bicycle("Red","BSA");
	}

}
