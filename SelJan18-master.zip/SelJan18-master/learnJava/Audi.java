package learnJava;

public class Audi extends Car{
	
	public void turnCruiseMode(){
		
	}
}
