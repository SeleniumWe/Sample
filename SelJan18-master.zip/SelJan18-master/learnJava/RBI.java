package learnJava;

public interface RBI extends IMF{
	
	//public void minimumIntRate();
	
	public void mandatoryAdhaar();
	
	public void mandatoryPAN();

}
