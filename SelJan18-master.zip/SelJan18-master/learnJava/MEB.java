package learnJava;

public interface MEB extends IMF{
	
	public void maintainsExchangeRate();

}
