package learnJava;

public interface IMF {

}
