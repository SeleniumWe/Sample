package learnJava;

public class BMW extends Car{
	
	public void turnSportsMode(){
		
	}

}
