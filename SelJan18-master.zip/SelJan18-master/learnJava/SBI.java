package learnJava;

public class SBI implements RBI, MEB{

	public void minimumIntRate() {
		System.out.println("7%");		
	}

	public void mandatoryAdhaar() {
		System.out.println("SMS");		
	}
	
	public void discountForSeleniumImp(){
		
	}

	public void mandatoryPAN() {
		// TODO Auto-generated method stub
		
	}

	public void maintainsExchangeRate() {
		// TODO Auto-generated method stub
		
	}

}
