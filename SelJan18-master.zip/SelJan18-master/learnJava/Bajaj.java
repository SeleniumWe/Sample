package learnJava;

public class Bajaj extends Auto{
	
	
}
