package learnJava;

public class Vehicle {

	public void soundHorn(){

	}

	public void applyBrake(){

	}

}
