package learnJava;

public class Car extends Vehicle{
	
	public void turnAC(){
		
	}
	

}
