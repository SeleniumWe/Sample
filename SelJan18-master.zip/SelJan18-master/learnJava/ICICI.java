package learnJava;

public class ICICI implements RBI{

	/*public void minimumIntRate() {
		System.out.println("8%");
		
	}*/

	public void mandatoryAdhaar() {
		System.out.println("Email");
		
	}

	public void mandatoryPAN() {
		// TODO Auto-generated method stub
		
	}

}
